res/edje/main.edj: \
  C:/Users/intel/workspace/ArensSchedule/edje/images/recent_no_recent_icon.png \
  C:/Users/intel/workspace/ArensSchedule/edje/images/recent_no_item_bg.png \
  C:/Users/intel/workspace/ArensSchedule/edje/images/widget_circle_bg_ef1.png \
  C:/Users/intel/workspace/ArensSchedule/edje/images/widget_circle_bg_ef2.png \
  C:/Users/intel/workspace/ArensSchedule/edje/images/recent_circle_bg_mask.png \
  C:/Users/intel/workspace/ArensSchedule/edje/images/b_recent_widget_del_bg.png \
  C:/Users/intel/workspace/ArensSchedule/edje/images/b_recent_widget_del_icon.png