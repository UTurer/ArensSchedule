/*
 * Copyright (c) 2015 Samsung Electronics Co., Ltd
 *
 * Licensed under the Flora License, Version 1.1 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://floralicense.org/license/
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <tizen.h>
#include <app.h>
#include <Elementary.h>
#include <efl_extension.h>
#include <system_settings.h>
#include <dlog.h>
#include <math.h>

#define PADDING_END "padding_end"
#define TIMER_INTERVAL 10.0
#define CLOCK_OVERRIDE_ENABLED 0
#define CLOCK_OVERRIDE_DAY 0 //0: Monday, 1: Tuesday etc.
#define CLOCK_OVERRIDE_HOUR 9
#define CLOCK_OVERRIDE_MIN 3
#define CLOCK_OVERRIDE_SEC 0

#define COLOR_PAST1 "242424"
#define COLOR_PAST2 "343434"
#define COLOR_NOW1 "FFFF00"
#define COLOR_NOW2 "DAA520"
#define COLOR_FUTURE1 "FFFFFF"
#define COLOR_FUTURE2 "ADD8E6"

static Ecore_Timer *debug_clock_timer = NULL;
static struct tm debug_clock;

typedef struct period {
	char majornum[2];
	char minornum[2];
	char name[40];
	char room[16];
	int start_hour;
	int start_min;
	int end_hour;
	int end_min;
	int duration_in_minutes;
} period_s;

typedef struct dailyschedule {
	char nameofday[16];
	char typeofday[16];
	int numperiods;
	period_s *periodlist;
} dailyschedule_s;

typedef struct schedule {
	dailyschedule_s dailyschedulelist[7];
} schedule_s;

typedef struct appdata {
	Evas_Object *win;
	Eext_Circle_Surface *circle_surface;
	Evas_Object *naviframe;
	Evas_Object *conform;
	Evas_Object *scroller;
	Evas_Object *box;
	Evas_Object *layout;
	Evas_Object *slider;
	Evas_Object *slider_label;
	double slider_prev_val;
	Evas_Object *title_label;
	Evas_Object *index;
	schedule_s *schedule;
	Evas_Object **listOfProgressBarsToUpdate;
	Evas_Object **listOfLabelsToUpdate;
	int last_update_wday;
	int last_update_hour;
	int last_update_minute;
	Ecore_Timer *timer_RefreshGUI;
} appdata_s;

static appdata_s ad = {
	.win = NULL,
	.circle_surface = NULL,
	.naviframe = NULL,
	.conform = NULL,
	.scroller = NULL,
	.box = NULL,
	.layout = NULL,
	.slider = NULL,
	.slider_label = NULL,
	.slider_prev_val = -1.0,
	.title_label = NULL,
	.index = NULL,
	.schedule = NULL,
    .listOfProgressBarsToUpdate = NULL,
    .listOfLabelsToUpdate = NULL,
	.last_update_wday = -1,
	.last_update_hour = -1,
	.last_update_minute = -1,
	.timer_RefreshGUI = NULL,
};

static void _win_delete_request_cb(void *user_data, Evas_Object *obj, void *event_info);
static void delete_all_labels_and_progressbars(Evas_Object *parent);
static void populateGUI(struct tm *timeinfo);
static void updateGUI(struct tm *timeinfo);
static void slider_changed_cb(void *data, Evas_Object *obj, void *event_info);
static Eina_Bool timer_RefreshGUI_cb(void *data);
static int convertSundayBasedWdayToMondayBasedWday(int sundayBasedWday);
static int convertMondayBasedWdayToSundayBasedWday(int mondayBasedWday);
static struct tm * getCurrentTime();
//static char* _progress_format_cb(double val);
//static void _progress_format_free(char *str);

static struct tm * getCurrentTime()
{
	time_t t = time(NULL);
	struct tm *timeinfo = localtime(&t);

	if (CLOCK_OVERRIDE_ENABLED && debug_clock_timer != NULL)
	{
		timeinfo=&debug_clock;
	}

	return(timeinfo);
}


void print_type(Evas_Object *obj) {
	const char *type = evas_object_type_get(obj);
	if (type) {
		dlog_print(DLOG_INFO, "MY_TAG", "Object type: %s\n", type);
	} else {
		dlog_print(DLOG_INFO, "MY_TAG", "Object type is unknown.\n");
	}
}

static void back_button_cb(void *data, Evas_Object *obj, void *event_info)
{
    appdata_s *ad = (appdata_s *)data;

    if(ad->naviframe != NULL)
    {
    	if (elm_naviframe_top_item_get(ad->naviframe) != elm_naviframe_bottom_item_get(ad->naviframe))
		{
			elm_naviframe_item_pop(ad->naviframe);
		}
		else
		{
			elm_win_lower(ad->win); // Minimize the app
		}
    }
    else
    {
    	elm_win_lower(ad->win); // Minimize the app
    }

}

static schedule_s* populate_schedule()
{
	dailyschedule_s AnchorDaySchedule;
	dailyschedule_s OddDaySchedule;
	dailyschedule_s EvenDaySchedule;
	dailyschedule_s WeekendSchedule;
	static schedule_s schedule;
	time_t t;
	struct tm * timeinfo;
	int i;
	dailyschedule_s *ptr_s;

	// Get the current time
	t=time(NULL);
	timeinfo = localtime(&t);

	i=0;
	ptr_s = &AnchorDaySchedule;
	ptr_s->numperiods = 16;
	ptr_s->periodlist = (period_s *)malloc(ptr_s->numperiods * sizeof(period_s));
	sprintf(ptr_s->typeofday, "Anchor Day");
	sprintf(ptr_s->periodlist[i].majornum, "1");
	sprintf(ptr_s->periodlist[i].minornum, "0");
	sprintf(ptr_s->periodlist[i].name, "Computers in Art");
	sprintf(ptr_s->periodlist[i].room, "Room 116");
	ptr_s->periodlist[i].start_hour = 7;
	ptr_s->periodlist[i].start_min = 30;
	ptr_s->periodlist[i].end_hour = 8;
	ptr_s->periodlist[i].end_min = 14;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, " ");
	sprintf(ptr_s->periodlist[i].minornum, " ");
	sprintf(ptr_s->periodlist[i].name, "5 min. break");
	sprintf(ptr_s->periodlist[i].room, " ");
	ptr_s->periodlist[i].start_hour = 8;
	ptr_s->periodlist[i].start_min = 14;
	ptr_s->periodlist[i].end_hour = 8;
	ptr_s->periodlist[i].end_min = 19;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "2");
	sprintf(ptr_s->periodlist[i].minornum, "0");
	sprintf(ptr_s->periodlist[i].name, "Health & PE 7");
	sprintf(ptr_s->periodlist[i].room, "Gym 1");
	ptr_s->periodlist[i].start_hour = 8;
	ptr_s->periodlist[i].start_min = 19;
	ptr_s->periodlist[i].end_hour = 9;
	ptr_s->periodlist[i].end_min = 1;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, " ");
	sprintf(ptr_s->periodlist[i].minornum, " ");
	sprintf(ptr_s->periodlist[i].name, "5 min. break");
	sprintf(ptr_s->periodlist[i].room, " ");
	ptr_s->periodlist[i].start_hour = 9;
	ptr_s->periodlist[i].start_min = 1;
	ptr_s->periodlist[i].end_hour = 9;
	ptr_s->periodlist[i].end_min = 6;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "3");
	sprintf(ptr_s->periodlist[i].minornum, "0");
	sprintf(ptr_s->periodlist[i].name, "Intermediate Orchestra");
	sprintf(ptr_s->periodlist[i].room, "Room 163");
	ptr_s->periodlist[i].start_hour = 9;
	ptr_s->periodlist[i].start_min = 6;
	ptr_s->periodlist[i].end_hour = 9;
	ptr_s->periodlist[i].end_min = 48;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, " ");
	sprintf(ptr_s->periodlist[i].minornum, " ");
	sprintf(ptr_s->periodlist[i].name, "5 min. break");
	sprintf(ptr_s->periodlist[i].room, " ");
	ptr_s->periodlist[i].start_hour = 9;
	ptr_s->periodlist[i].start_min = 48;
	ptr_s->periodlist[i].end_hour = 9;
	ptr_s->periodlist[i].end_min = 53;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "5");
	sprintf(ptr_s->periodlist[i].minornum, "0");
	sprintf(ptr_s->periodlist[i].name, "Life Science HN");
	sprintf(ptr_s->periodlist[i].room, "Room 146");
	ptr_s->periodlist[i].start_hour = 9;
	ptr_s->periodlist[i].start_min = 53;
	ptr_s->periodlist[i].end_hour = 10;
	ptr_s->periodlist[i].end_min = 35;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, " ");
	sprintf(ptr_s->periodlist[i].minornum, " ");
	sprintf(ptr_s->periodlist[i].name, "5 min. break");
	sprintf(ptr_s->periodlist[i].room, " ");
	ptr_s->periodlist[i].start_hour = 10;
	ptr_s->periodlist[i].start_min = 35;
	ptr_s->periodlist[i].end_hour = 10;
	ptr_s->periodlist[i].end_min = 40;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "6");
	sprintf(ptr_s->periodlist[i].minornum, "1");
	sprintf(ptr_s->periodlist[i].name, "SEL Lesson (Social Emotional Learning)");
	sprintf(ptr_s->periodlist[i].room, "Room ???");
	ptr_s->periodlist[i].start_hour = 10;
	ptr_s->periodlist[i].start_min = 40;
	ptr_s->periodlist[i].end_hour = 11;
	ptr_s->periodlist[i].end_min = 10;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "6");
	sprintf(ptr_s->periodlist[i].minornum, "2");
	sprintf(ptr_s->periodlist[i].name, "B Lunch");
	sprintf(ptr_s->periodlist[i].room, "Room ???");
	ptr_s->periodlist[i].start_hour = 11;
	ptr_s->periodlist[i].start_min = 10;
	ptr_s->periodlist[i].end_hour = 11;
	ptr_s->periodlist[i].end_min = 40;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "6");
	sprintf(ptr_s->periodlist[i].minornum, "3");
	sprintf(ptr_s->periodlist[i].name, "English 7 HN");
	sprintf(ptr_s->periodlist[i].room, "Room 150");
	ptr_s->periodlist[i].start_hour = 11;
	ptr_s->periodlist[i].start_min = 40;
	ptr_s->periodlist[i].end_hour = 12;
	ptr_s->periodlist[i].end_min = 25;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "6");
	sprintf(ptr_s->periodlist[i].minornum, "4");
	sprintf(ptr_s->periodlist[i].name, "Recess");
	sprintf(ptr_s->periodlist[i].room, "Room ???");
	ptr_s->periodlist[i].start_hour = 12;
	ptr_s->periodlist[i].start_min = 25;
	ptr_s->periodlist[i].end_hour = 12;
	ptr_s->periodlist[i].end_min = 40;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, " ");
	sprintf(ptr_s->periodlist[i].minornum, " ");
	sprintf(ptr_s->periodlist[i].name, "5 min. break");
	sprintf(ptr_s->periodlist[i].room, " ");
	ptr_s->periodlist[i].start_hour = 12;
	ptr_s->periodlist[i].start_min = 40;
	ptr_s->periodlist[i].end_hour = 12;
	ptr_s->periodlist[i].end_min = 45;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "7");
	sprintf(ptr_s->periodlist[i].minornum, "0");
	sprintf(ptr_s->periodlist[i].name, "US History 7 HN");
	sprintf(ptr_s->periodlist[i].room, "Room 148");
	ptr_s->periodlist[i].start_hour = 12;
	ptr_s->periodlist[i].start_min = 45;
	ptr_s->periodlist[i].end_hour = 13;
	ptr_s->periodlist[i].end_min = 27;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, " ");
	sprintf(ptr_s->periodlist[i].minornum, " ");
	sprintf(ptr_s->periodlist[i].name, "5 min. break");
	sprintf(ptr_s->periodlist[i].room, " ");
	ptr_s->periodlist[i].start_hour =13;
	ptr_s->periodlist[i].start_min = 27;
	ptr_s->periodlist[i].end_hour = 13;
	ptr_s->periodlist[i].end_min = 32;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "8");
	sprintf(ptr_s->periodlist[i].minornum, "0");
	sprintf(ptr_s->periodlist[i].name, "Mathematics 7 HN");
	sprintf(ptr_s->periodlist[i].room, "Room 207");
	ptr_s->periodlist[i].start_hour = 13;
	ptr_s->periodlist[i].start_min = 32;
	ptr_s->periodlist[i].end_hour = 14;
	ptr_s->periodlist[i].end_min = 15;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=0;
	ptr_s = &OddDaySchedule;
	ptr_s->numperiods = 10;
	ptr_s->periodlist = (period_s *)malloc(ptr_s->numperiods * sizeof(period_s));
	sprintf(ptr_s->typeofday, "Odd/Blue Day");
	sprintf(ptr_s->periodlist[i].majornum, "1");
	sprintf(ptr_s->periodlist[i].minornum, "0");
	sprintf(ptr_s->periodlist[i].name, "Computers in Art");
	sprintf(ptr_s->periodlist[i].room, "Room 116");
	ptr_s->periodlist[i].start_hour = 7;
	ptr_s->periodlist[i].start_min = 30;
	ptr_s->periodlist[i].end_hour = 8;
	ptr_s->periodlist[i].end_min = 55;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, " ");
	sprintf(ptr_s->periodlist[i].minornum, " ");
	sprintf(ptr_s->periodlist[i].name, "5 min. break");
	sprintf(ptr_s->periodlist[i].room, " ");
	ptr_s->periodlist[i].start_hour = 8;
	ptr_s->periodlist[i].start_min = 55;
	ptr_s->periodlist[i].end_hour = 9;
	ptr_s->periodlist[i].end_min = 0;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "3");
	sprintf(ptr_s->periodlist[i].minornum, "0");
	sprintf(ptr_s->periodlist[i].name, "Intermediate Orchestra");
	sprintf(ptr_s->periodlist[i].room, "Room 163");
	ptr_s->periodlist[i].start_hour = 9;
	ptr_s->periodlist[i].start_min = 0;
	ptr_s->periodlist[i].end_hour = 9;
	ptr_s->periodlist[i].end_min = 45;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, " ");
	sprintf(ptr_s->periodlist[i].minornum, " ");
	sprintf(ptr_s->periodlist[i].name, "5 min. break");
	sprintf(ptr_s->periodlist[i].room, " ");
	ptr_s->periodlist[i].start_hour = 9;
	ptr_s->periodlist[i].start_min = 45;
	ptr_s->periodlist[i].end_hour = 9;
	ptr_s->periodlist[i].end_min = 50;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "4");
	sprintf(ptr_s->periodlist[i].minornum, "0");
	sprintf(ptr_s->periodlist[i].name, "Learning Seminar and Recess");
	sprintf(ptr_s->periodlist[i].room, "Room 207");
	ptr_s->periodlist[i].start_hour = 9;
	ptr_s->periodlist[i].start_min = 50;
	ptr_s->periodlist[i].end_hour = 10;
	ptr_s->periodlist[i].end_min = 40;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, " ");
	sprintf(ptr_s->periodlist[i].minornum, " ");
	sprintf(ptr_s->periodlist[i].name, "5 min. break");
	sprintf(ptr_s->periodlist[i].room, " ");
	ptr_s->periodlist[i].start_hour = 10;
	ptr_s->periodlist[i].start_min = 40;
	ptr_s->periodlist[i].end_hour = 10;
	ptr_s->periodlist[i].end_min = 45;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "5");
	sprintf(ptr_s->periodlist[i].minornum, "1");
	sprintf(ptr_s->periodlist[i].name, "A Lunch");
	sprintf(ptr_s->periodlist[i].room, "Room ???");
	ptr_s->periodlist[i].start_hour = 10;
	ptr_s->periodlist[i].start_min = 45;
	ptr_s->periodlist[i].end_hour = 11;
	ptr_s->periodlist[i].end_min = 15;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "5");
	sprintf(ptr_s->periodlist[i].minornum, "2");
	sprintf(ptr_s->periodlist[i].name, "Life Science HN");
	sprintf(ptr_s->periodlist[i].room, "Room 146");
	ptr_s->periodlist[i].start_hour = 11;
	ptr_s->periodlist[i].start_min = 15;
	ptr_s->periodlist[i].end_hour = 12;
	ptr_s->periodlist[i].end_min = 45;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, " ");
	sprintf(ptr_s->periodlist[i].minornum, " ");
	sprintf(ptr_s->periodlist[i].name, "5 min. break");
	sprintf(ptr_s->periodlist[i].room, " ");
	ptr_s->periodlist[i].start_hour = 12;
	ptr_s->periodlist[i].start_min = 45;
	ptr_s->periodlist[i].end_hour = 12;
	ptr_s->periodlist[i].end_min = 50;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "7");
	sprintf(ptr_s->periodlist[i].minornum, "0");
	sprintf(ptr_s->periodlist[i].name, "US History 7 HN");
	sprintf(ptr_s->periodlist[i].room, "Room 148");
	ptr_s->periodlist[i].start_hour = 12;
	ptr_s->periodlist[i].start_min = 50;
	ptr_s->periodlist[i].end_hour = 14;
	ptr_s->periodlist[i].end_min = 15;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=0;
	ptr_s = &EvenDaySchedule;
	ptr_s->numperiods = 11;
	ptr_s->periodlist = (period_s *)malloc(ptr_s->numperiods * sizeof(period_s));
	sprintf(ptr_s->typeofday, "Even/Silver Day");
	sprintf(ptr_s->periodlist[i].majornum, "2");
	sprintf(ptr_s->periodlist[i].minornum, "0");
	sprintf(ptr_s->periodlist[i].name, "Health & PE 7");
	sprintf(ptr_s->periodlist[i].room, "Gym 1");
	ptr_s->periodlist[i].start_hour = 7;
	ptr_s->periodlist[i].start_min = 30;
	ptr_s->periodlist[i].end_hour = 8;
	ptr_s->periodlist[i].end_min = 55;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, " ");
	sprintf(ptr_s->periodlist[i].minornum, " ");
	sprintf(ptr_s->periodlist[i].name, "5 min. break");
	sprintf(ptr_s->periodlist[i].room, " ");
	ptr_s->periodlist[i].start_hour =8;
	ptr_s->periodlist[i].start_min = 55;
	ptr_s->periodlist[i].end_hour = 9;
	ptr_s->periodlist[i].end_min = 0;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "3");
	sprintf(ptr_s->periodlist[i].minornum, "0");
	sprintf(ptr_s->periodlist[i].name, "Intermediate Orchestra");
	sprintf(ptr_s->periodlist[i].room, "Room 163");
	ptr_s->periodlist[i].start_hour = 9;
	ptr_s->periodlist[i].start_min = 0;
	ptr_s->periodlist[i].end_hour = 9;
	ptr_s->periodlist[i].end_min = 45;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, " ");
	sprintf(ptr_s->periodlist[i].minornum, " ");
	sprintf(ptr_s->periodlist[i].name, "5 min. break");
	sprintf(ptr_s->periodlist[i].room, " ");
	ptr_s->periodlist[i].start_hour = 9;
	ptr_s->periodlist[i].start_min = 45;
	ptr_s->periodlist[i].end_hour = 9;
	ptr_s->periodlist[i].end_min = 50;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "4");
	sprintf(ptr_s->periodlist[i].minornum, "0");
	sprintf(ptr_s->periodlist[i].name, "Learning Seminar and Recess");
	sprintf(ptr_s->periodlist[i].room, "Room 207");
	ptr_s->periodlist[i].start_hour = 9;
	ptr_s->periodlist[i].start_min = 50;
	ptr_s->periodlist[i].end_hour = 10;
	ptr_s->periodlist[i].end_min = 40;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, " ");
	sprintf(ptr_s->periodlist[i].minornum, " ");
	sprintf(ptr_s->periodlist[i].name, "5 min. break");
	sprintf(ptr_s->periodlist[i].room, " ");
	ptr_s->periodlist[i].start_hour = 10;
	ptr_s->periodlist[i].start_min = 40;
	ptr_s->periodlist[i].end_hour = 10;
	ptr_s->periodlist[i].end_min = 45;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "6");
	sprintf(ptr_s->periodlist[i].minornum, "1");
	sprintf(ptr_s->periodlist[i].name, "English 7 HN");
	sprintf(ptr_s->periodlist[i].room, "Room 150");
	ptr_s->periodlist[i].start_hour = 10;
	ptr_s->periodlist[i].start_min = 45;
	ptr_s->periodlist[i].end_hour = 11;
	ptr_s->periodlist[i].end_min = 15;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "6");
	sprintf(ptr_s->periodlist[i].minornum, "2");
	sprintf(ptr_s->periodlist[i].name, "B Lunch");
	sprintf(ptr_s->periodlist[i].room, "Room ???");
	ptr_s->periodlist[i].start_hour = 11;
	ptr_s->periodlist[i].start_min = 15;
	ptr_s->periodlist[i].end_hour = 11;
	ptr_s->periodlist[i].end_min = 45;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "6");
	sprintf(ptr_s->periodlist[i].minornum, "3");
	sprintf(ptr_s->periodlist[i].name, "English 7 HN");
	sprintf(ptr_s->periodlist[i].room, "Room 150");
	ptr_s->periodlist[i].start_hour = 11;
	ptr_s->periodlist[i].start_min = 45;
	ptr_s->periodlist[i].end_hour = 12;
	ptr_s->periodlist[i].end_min = 45;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, " ");
	sprintf(ptr_s->periodlist[i].minornum, " ");
	sprintf(ptr_s->periodlist[i].name, "5 min. break");
	sprintf(ptr_s->periodlist[i].room, " ");
	ptr_s->periodlist[i].start_hour = 12;
	ptr_s->periodlist[i].start_min = 45;
	ptr_s->periodlist[i].end_hour = 12;
	ptr_s->periodlist[i].end_min = 50;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=i+1;
	sprintf(ptr_s->periodlist[i].majornum, "8");
	sprintf(ptr_s->periodlist[i].minornum, "0");
	sprintf(ptr_s->periodlist[i].name, "Mathematics 7 HN");
	sprintf(ptr_s->periodlist[i].room, "Room 207");
	ptr_s->periodlist[i].start_hour = 12;
	ptr_s->periodlist[i].start_min = 50;
	ptr_s->periodlist[i].end_hour = 14;
	ptr_s->periodlist[i].end_min = 15;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	i=0;
	ptr_s = &WeekendSchedule;
	ptr_s->numperiods = 1;
	ptr_s->periodlist = (period_s *)malloc(ptr_s->numperiods * sizeof(period_s));
	sprintf(ptr_s->typeofday, "Weekend");
	sprintf(ptr_s->periodlist[i].majornum, " ");
	sprintf(ptr_s->periodlist[i].minornum, " ");
	sprintf(ptr_s->periodlist[i].name, "Weekend");
	sprintf(ptr_s->periodlist[i].room, "Room ???");
	ptr_s->periodlist[i].start_hour = 7;
	ptr_s->periodlist[i].start_min = 30;
	ptr_s->periodlist[i].end_hour = 14;
	ptr_s->periodlist[i].end_min = 15;
	ptr_s->periodlist[i].duration_in_minutes = (ptr_s->periodlist[i].end_hour-ptr_s->periodlist[i].start_hour)*60+(ptr_s->periodlist[i].end_min-ptr_s->periodlist[i].start_min);

	schedule.dailyschedulelist[0] = AnchorDaySchedule;
	sprintf(schedule.dailyschedulelist[0].nameofday, "Monday");
	schedule.dailyschedulelist[1] = OddDaySchedule;
	sprintf(schedule.dailyschedulelist[1].nameofday, "Tuesday");
	schedule.dailyschedulelist[2] = EvenDaySchedule;
	sprintf(schedule.dailyschedulelist[2].nameofday, "Wednesday");
	schedule.dailyschedulelist[3] = OddDaySchedule;
	sprintf(schedule.dailyschedulelist[3].nameofday, "Thursday");
	schedule.dailyschedulelist[4] = EvenDaySchedule;
	sprintf(schedule.dailyschedulelist[4].nameofday, "Friday");
	schedule.dailyschedulelist[5] = WeekendSchedule;
	sprintf(schedule.dailyschedulelist[5].nameofday, "Saturday");
	schedule.dailyschedulelist[6] = WeekendSchedule;
	sprintf(schedule.dailyschedulelist[6].nameofday, "Sunday");

	return(&schedule);
}

static void slider_changed_cb(void *data, Evas_Object *obj, void *event_info)
{
    double val = elm_slider_value_get(obj);
    val = round(val);

    if (val != ad.slider_prev_val)
    {
    	char tmp3[64];
		switch((int)val)
		{
			case 0:
				snprintf(tmp3, sizeof(tmp3), "<align=center>Use calendar day</align>");
				elm_object_text_set(ad.slider_label, tmp3);
				break;
			case 1:
				snprintf(tmp3, sizeof(tmp3), "<align=center>Set as anchor day</align>");
				elm_object_text_set(ad.slider_label, tmp3);
				break;
			case 2:
				snprintf(tmp3, sizeof(tmp3), "<align=center>Set as odd/blue day</align>");
				elm_object_text_set(ad.slider_label, tmp3);
				break;
			case 3:
				snprintf(tmp3, sizeof(tmp3), "<align=center>Set as even/silver day</align>");
				elm_object_text_set(ad.slider_label, tmp3);
				break;
			case 4:
				snprintf(tmp3, sizeof(tmp3), "<align=center>Set as weekend</align>");
				elm_object_text_set(ad.slider_label, tmp3);
				break;
		}

		struct tm *timeinfo = getCurrentTime();
	    populateGUI(timeinfo);

	    // Update previous val
	    ad.slider_prev_val = val;
    }
}

static void populateGUI(struct tm *timeinfo)
{
	int i;
	Evas_Object *item = NULL;
	Evas_Object *padding = NULL;
	char tmp3[1024];
	char tmp1[6];
	char tmp2[6];
	int slider_day;

	double val = elm_slider_value_get(ad.slider);
	val = round(val);
	switch((int)val)
	{
		case 0:
			slider_day = convertSundayBasedWdayToMondayBasedWday(timeinfo->tm_wday);
			break;
		case 1:
			slider_day = 0;
			break;
		case 2:
			slider_day = 1;
			break;
		case 3:
			slider_day = 2;
			break;
		case 4:
			slider_day = 5;
			break;
	}

//	dlog_print(DLOG_INFO, "MY_TAG", "Beginning of populateGUI()");
//	dlog_print(DLOG_INFO, "MY_TAG", "Current day is %d", day);

	// Free the previously allocated memory
	if (ad.listOfProgressBarsToUpdate != NULL)
	{
		free(ad.listOfProgressBarsToUpdate);
		ad.listOfProgressBarsToUpdate = NULL;
	}
	if (ad.listOfLabelsToUpdate != NULL)
	{
		free(ad.listOfLabelsToUpdate);
		ad.listOfLabelsToUpdate = NULL;
	}
	ad.listOfProgressBarsToUpdate = (Evas_Object **)malloc(ad.schedule->dailyschedulelist[slider_day].numperiods * sizeof(Evas_Object *));
	ad.listOfLabelsToUpdate = (Evas_Object **)malloc(ad.schedule->dailyschedulelist[slider_day].numperiods * sizeof(Evas_Object *));

	delete_all_labels_and_progressbars(ad.box);

//	item = elm_label_add(ad.box);
//	elm_label_line_wrap_set(item, ELM_WRAP_MIXED); // Enable line wrapping
//	evas_object_size_hint_min_set(item, 300, 0); // Adjust the size as needed
//	snprintf(tmp3, sizeof(tmp3), "<align=center>%s<br>"
//									"%s</align>",
//									ad.schedule->dailyschedulelist[day].nameofday,ad.schedule->dailyschedulelist[slider_day].typeofday);
//	elm_object_text_set(item, tmp3);
//	evas_object_show(item);
//	padding = evas_object_data_get(ad.box, PADDING_END);
//	elm_box_pack_before(ad.box, item, padding);

	for (i = 0; i<ad.schedule->dailyschedulelist[slider_day].numperiods; i++)
	{
		int _start_hour = ad.schedule->dailyschedulelist[slider_day].periodlist[i].start_hour;
		int _end_hour = ad.schedule->dailyschedulelist[slider_day].periodlist[i].end_hour;
		int _start_min = ad.schedule->dailyschedulelist[slider_day].periodlist[i].start_min;
		int _end_min = ad.schedule->dailyschedulelist[slider_day].periodlist[i].end_min;
		char *_minornum = ad.schedule->dailyschedulelist[slider_day].periodlist[i].minornum;
		char *_majornum = ad.schedule->dailyschedulelist[slider_day].periodlist[i].majornum;
		char *_name = ad.schedule->dailyschedulelist[slider_day].periodlist[i].name;
		char *_room = ad.schedule->dailyschedulelist[slider_day].periodlist[i].room;
		int _duration_in_minutes = ad.schedule->dailyschedulelist[slider_day].periodlist[i].duration_in_minutes;

		item = elm_label_add(ad.box);
		elm_label_line_wrap_set(item, ELM_WRAP_MIXED); // Enable line wrapping
		evas_object_size_hint_min_set(item, 300, 0); // Adjust the size as needed
		snprintf(tmp1, sizeof(tmp1), "%02d:%02d", _start_hour, _start_min);
		snprintf(tmp2, sizeof(tmp1), "%02d:%02d", _end_hour, _end_min);
		if(strcmp(ad.schedule->dailyschedulelist[slider_day].periodlist[i].majornum, " ") == 0)
		{
			snprintf(tmp3, sizeof(tmp3), "<align=center><color=#FFFFFF>%s</color><br>"
											"<color=#FFFFFF>%s</color><br>"
											"<color=#FFFFFF>%s</color><br>"
											"<color=#FFFFFF>%s - %s</color><br>"
											"<color=#FFFFFF>(%d min.)</color></align><",
											_majornum, _name, _room, tmp1, tmp2, _duration_in_minutes);
		}
		else
		{
			if(strcmp(_minornum, "0") == 0)
			{
				snprintf(tmp3, sizeof(tmp3), "<align=center><color=#FFFFFF>Period %s</color><br>"
												"<color=#FFFFFF>%s</color><br>"
												"<color=#FFFFFF>%s</color><br>"
												"<color=#FFFFFF>%s - %s</color><br>"
												"<color=#FFFFFF>(%d min.)</color></align>",
												_majornum, _name, _room, tmp1, tmp2, _duration_in_minutes);
			}
			else
			{
				snprintf(tmp3, sizeof(tmp3), "<align=center><color=#FFFFFF>Period %s.%s</color><br>"
												"<color=#FFFFFF>%s</color><br>"
												"<color=#FFFFFF>%s</color><br>"
												"<color=#FFFFFF>%s - %s</color><br>"
												"<color=#FFFFFF>(%d min.)</color></align>",
												_majornum, _minornum, _name, _room, tmp1, tmp2, _duration_in_minutes);
			}
		}
		elm_object_text_set(item, tmp3);
		//elm_object_style_set(item, "slide_roll");
		//elm_label_slide_duration_set(item, 3);
		//elm_label_slide_mode_set(item, ELM_LABEL_SLIDE_MODE_ALWAYS);
		//evas_object_size_hint_weight_set(item, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
		evas_object_show(item);
		padding = evas_object_data_get(ad.box, PADDING_END);
		elm_box_pack_before(ad.box, item, padding);
//		Evas_Object* parent = evas_object_smart_parent_get(item);
//		print_type(item);
		ad.listOfLabelsToUpdate[i] = item;

		item = elm_progressbar_add(ad.layout);
		evas_object_size_hint_weight_set(item, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
		//snprintf(tmp, sizeof(tmp), "Label %d", i);
		//elm_object_text_set(item,tmp);
//		elm_progressbar_unit_format_function_set(item, _progress_format_cb,_progress_format_free);
		elm_progressbar_span_size_set(item, 200);
		evas_object_size_hint_align_set(item, EVAS_HINT_FILL*-1*0.5, 0.5);
		evas_object_size_hint_weight_set(item, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
		elm_progressbar_value_set(item, 0.5);
		evas_object_show(item);
		padding = evas_object_data_get(ad.box, PADDING_END);
		elm_box_pack_before(ad.box, item, padding);
		ad.listOfProgressBarsToUpdate[i] = item;
//		print_type(item);

	}
	updateGUI(timeinfo);
//	dlog_print(DLOG_INFO, "MY_TAG", "End of populateGUI()");
}

static void updateGUI(struct tm *timeinfo)
{
	int i;
	int diff_in_seconds;
	int duration;
	int mins_progressed;
	const char *current_text;

	const char *start;
	const char *end;
	char *color_start;
	double percent_complete;
	char updated_text[512]; // Adjust size as needed
	char color1[7];
	char color2[7];
	char color3[7];
	char color4[7];
	char color5[7];
	char tmp3[128];
	size_t prefix_len;

	int slider_day;
	double val = elm_slider_value_get(ad.slider);
	val = round(val);
	switch((int)val)
	{
		case 0:
			slider_day = convertSundayBasedWdayToMondayBasedWday(timeinfo->tm_wday);
			break;
		case 1:
			slider_day = 0;
			break;
		case 2:
			slider_day = 1;
			break;
		case 3:
			slider_day = 2;
			break;
		case 4:
			slider_day = 5;
			break;
	}

	int mondayBasedWday = convertSundayBasedWdayToMondayBasedWday(timeinfo->tm_wday);
	snprintf(tmp3, sizeof(tmp3), "<align=center>%s<br>%s</align>",ad.schedule->dailyschedulelist[mondayBasedWday].nameofday,ad.schedule->dailyschedulelist[slider_day].typeofday);
	elm_object_text_set(ad.title_label, tmp3);

	for(i=0;i<ad.schedule->dailyschedulelist[slider_day].numperiods;i++)
	{
		// Calculate the difference in seconds
		diff_in_seconds = (timeinfo->tm_hour-ad.schedule->dailyschedulelist[slider_day].periodlist[i].start_hour)*3600+(timeinfo->tm_min-ad.schedule->dailyschedulelist[slider_day].periodlist[i].start_min)*60;
		percent_complete = ((double)diff_in_seconds)/(ad.schedule->dailyschedulelist[slider_day].periodlist[i].duration_in_minutes*60);
		if (percent_complete<0.0)
		{
			strcpy(color1, COLOR_FUTURE1);
			strcpy(color2, COLOR_FUTURE2);
			strcpy(color3, COLOR_FUTURE1);
			strcpy(color4, COLOR_FUTURE2);
			strcpy(color5, COLOR_FUTURE1);
		}
		else if (0.0<=percent_complete && percent_complete<1.0)
		{
			strcpy(color1, COLOR_NOW1);
			strcpy(color2, COLOR_NOW2);
			strcpy(color3, COLOR_NOW1);
			strcpy(color4, COLOR_NOW2);
			strcpy(color5, COLOR_NOW1);
		}
		else if (1.0<=percent_complete)
		{
			strcpy(color1, COLOR_PAST1);
			strcpy(color2, COLOR_PAST2);
			strcpy(color3, COLOR_PAST1);
			strcpy(color4, COLOR_PAST2);
			strcpy(color5, COLOR_PAST1);
		}

		if(percent_complete<0.0)
		{
			percent_complete = 0.0;
		}
		else if (percent_complete>1.0)
		{
			percent_complete = 1.0;
		}

		/* Replace progressed minutes text */
		elm_progressbar_value_set(ad.listOfProgressBarsToUpdate[i], percent_complete);
		duration = ad.schedule->dailyschedulelist[slider_day].periodlist[i].duration_in_minutes;
		mins_progressed = (int)(percent_complete*duration);
		snprintf(tmp3, sizeof(tmp3), "%d/%d min.", mins_progressed, duration);
		current_text = elm_object_text_get(ad.listOfLabelsToUpdate[i]);
		start = strchr(current_text, '(');
		end = strchr(current_text, ')');
		// Step 3: Copy the text before the parentheses
		prefix_len = start - current_text + 1; // Include '('
		strncpy(updated_text, current_text, prefix_len);
		updated_text[prefix_len] = '\0';
		// Step 4: Append the new text inside the parentheses
		strncat(updated_text, tmp3, sizeof(updated_text) - strlen(updated_text) - 1);
		// Step 5: Append the text after the parentheses (including ')')
		strncat(updated_text, end, sizeof(updated_text) - strlen(updated_text) - 1);

		/* Replace color codes */
		// Step 1: Find the location of the '#' character and replace the color code
		color_start = strstr(updated_text, "<color=#");
		color_start += 8; // Move the pointer to the start of the color code
		strncpy(color_start, color1, 6); // Replace the 6 characters of the color code
		color_start = strstr(color_start, "<color=#");
		color_start += 8; // Move the pointer to the start of the color code
		strncpy(color_start, color2, 6); // Replace the 6 characters of the color code
		color_start = strstr(color_start, "<color=#");
		color_start += 8; // Move the pointer to the start of the color code
		strncpy(color_start, color3, 6); // Replace the 6 characters of the color code
		color_start = strstr(color_start, "<color=#");
		color_start += 8; // Move the pointer to the start of the color code
		strncpy(color_start, color4, 6); // Replace the 6 characters of the color code
		color_start = strstr(color_start, "<color=#");
		color_start += 8; // Move the pointer to the start of the color code
		strncpy(color_start, color5, 6); // Replace the 6 characters of the color code

//		dlog_print(DLOG_INFO, "MY_TAG", "%s", updated_text);
		elm_object_text_set(ad.listOfLabelsToUpdate[i], updated_text);
	}

//	dlog_print(DLOG_INFO, "MY_TAG", "End of updateGUI()");
}

static Eina_Bool debug_clock_timer_cb(void *data)
{
	//dlog_print(DLOG_INFO, "MY_TAG", "Debug_Clock time is 1  : WDay %d, Hour %d, Min %d, Sec %d", debug_clock.tm_wday, debug_clock.tm_hour, debug_clock.tm_min, debug_clock.tm_sec);
	time_t t = mktime(&debug_clock);
	//dlog_print(DLOG_INFO, "MY_TAG", "Debug_Clock time is 2  : WDay %d, Hour %d, Min %d, Sec %d", debug_clock.tm_wday, debug_clock.tm_hour, debug_clock.tm_min, debug_clock.tm_sec);
	t = t+1;
	//dlog_print(DLOG_INFO, "MY_TAG", "Debug_Clock time is 3  : WDay %d, Hour %d, Min %d, Sec %d", debug_clock.tm_wday, debug_clock.tm_hour, debug_clock.tm_min, debug_clock.tm_sec);
	struct tm *new_timeinfo = localtime(&t);
	//dlog_print(DLOG_INFO, "MY_TAG", "Debug_Clock time is 4  : WDay %d, Hour %d, Min %d, Sec %d", debug_clock.tm_wday, debug_clock.tm_hour, debug_clock.tm_min, debug_clock.tm_sec);
	memcpy(&debug_clock, new_timeinfo, sizeof(struct tm));
	//dlog_print(DLOG_INFO, "MY_TAG", "Debug_Clock time is 5  : WDay %d, Hour %d, Min %d, Sec %d", debug_clock.tm_wday, debug_clock.tm_hour, debug_clock.tm_min, debug_clock.tm_sec);

	// Return ECORE_CALLBACK_RENEW to keep the timer running
	return ECORE_CALLBACK_RENEW;
}

static Eina_Bool timer_RefreshGUI_cb(void *data)
{
//	dlog_print(DLOG_INFO, "MY_TAG", "Beginning of timer_cb()");
//	dlog_print(DLOG_INFO, "MY_TAG", "Debug_Clock time is: WDay %d, Hour %d, Min %d, Sec %d", debug_clock.tm_wday, debug_clock.tm_hour, debug_clock.tm_min, debug_clock.tm_sec);

    struct tm *timeinfo;
    timeinfo = getCurrentTime();

    /* Check if day info changed. If it changed you need to repopulate objects on screen */
    if(timeinfo->tm_wday != ad.last_update_wday)
    {
    	populateGUI(timeinfo);
    	ad.last_update_wday = timeinfo->tm_wday;
    }

    /* Check if clock hour or minute is changed */
    if(timeinfo->tm_hour != ad.last_update_hour || timeinfo->tm_min != ad.last_update_minute)
    {
    	updateGUI(timeinfo);
    	ad.last_update_hour = timeinfo->tm_hour;
    	ad.last_update_minute = timeinfo->tm_min;
    }


//    dlog_print(DLOG_INFO, "MY_TAG", "Debug_Clock time is: WDay %d, Hour %d, Min %d, Sec %d", debug_clock.tm_wday, debug_clock.tm_hour, debug_clock.tm_min, debug_clock.tm_sec);
//    dlog_print(DLOG_INFO, "MY_TAG", "End of timer_cb()");

    // Return ECORE_CALLBACK_RENEW to keep the timer running
    return ECORE_CALLBACK_RENEW;
}

/* Format callback */
//static char* _progress_format_cb(double val)
//{
//   static char buf[30];
//   int files = (1-val)*14000;
//   if (snprintf(buf, 30, "%i files left", files) > 0)
//     return strdup(buf);
//   return NULL;
//}

//static void _progress_format_free(char *str)
//{
//   free(str);
//}

// Function to delete all child labels of a given parent
static void delete_all_labels_and_progressbars(Evas_Object *parent)
{
	Eina_List *children = evas_object_smart_members_get(parent);
	Eina_List *l;
	Evas_Object *child;

//	dlog_print(DLOG_INFO, "MY_TAG", "Beginning of delete_all_labels_and_progressbars()");
//	const char *type1 = evas_object_type_get(parent);
//	int count = eina_list_count(children);
//	dlog_print(DLOG_INFO, "MY_TAG", "type of parent is: %s\n", type1);
//	dlog_print(DLOG_INFO, "MY_TAG", "parent has %d children\n", count);
	EINA_LIST_FOREACH(children, l, child)
	{
		const char *type = evas_object_type_get(child);
//		dlog_print(DLOG_INFO, "MY_TAG", "type of child is: %s\n", type);
		if (strcmp(type, "elm_label") == 0 || strcmp(type, "elm_progressbar") == 0)
		{
			if (child != ad.slider_label && child != ad.title_label)
			{
				evas_object_del(child);
			}

//			dlog_print(DLOG_INFO, "MY_TAG", "deleted child of type %s\n", type);
		}
		else if (strcmp(type, "Evas_Object_Box")==0)
		{
			// Recursively check the children of container objects
			delete_all_labels_and_progressbars(child);
		}
	}
	eina_list_free(children);

//	dlog_print(DLOG_INFO, "MY_TAG", "End of delete_all_labels_and_progressbars()");
}

/*
 * @brief: Hook to take necessary actions before main event loop starts
 * Initialize UI resources and application's data
 * If this function returns true, the main loop of application starts
 * If this function returns false, the application is terminated
 */
static bool app_create(void *user_data)
{
	Evas_Object *padding_start = NULL;
	Evas_Object *padding_end = NULL;

//	dlog_print(DLOG_INFO, "MY_TAG", "beginning of app_create()");

	/* Window
	 *
	 * Create and initialize elm_win.
	 * elm_win is mandatory to manipulate window
	 */
	ad.win = elm_win_util_standard_add("com.utkuturer.arensschedule", "com.utkuturer.arensschedule");
	elm_win_conformant_set(ad.win, EINA_TRUE);
	elm_win_autodel_set(ad.win, EINA_TRUE);
	/* Rotation setting */
	if (elm_win_wm_rotation_supported_get(ad.win)) {
		int rots[4] = { 0, 90, 180, 270 };
		elm_win_wm_rotation_available_rotations_set(ad.win, (const int *)(&rots), 4);
	}
	evas_object_smart_callback_add(ad.win, "delete,request", _win_delete_request_cb, NULL);

	/*
	 * Conformant
	 * Create and initialize elm_conformant.
	 * elm_conformant is mandatory for base GUI to have proper size
	 * when indicator or virtual keypad is visible.
	 */
	ad.conform = elm_conformant_add(ad.win);
	evas_object_size_hint_weight_set(ad.conform, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	elm_win_resize_object_add(ad.win, ad.conform);
	evas_object_show(ad.conform);

	/* This make this application can show circular layout for wearable */
	//ad.circle_surface = eext_circle_surface_conformant_add(ad.conform);
	//ad.layout = view_create_layout_for_conformant_by_theme(s_info.conform, "layout", "application", "default");


	/* Naviframe */
	//Evas_Object* naviframe = elm_naviframe_add(conformant);
	//elm_object_content_set(conformant, naviframe);

	/* Layout */
	ad.layout = elm_layout_add(ad.conform);
	evas_object_size_hint_weight_set(ad.layout, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	elm_win_resize_object_add(ad.win, ad.layout);
	elm_layout_theme_set(ad.layout, "layout", "application", "default");
	evas_object_show(ad.layout);
	elm_object_content_set(ad.conform, ad.layout);

	ad.scroller = elm_scroller_add(ad.layout);
	elm_scroller_content_min_limit(ad.scroller, EINA_TRUE, EINA_FALSE);
	elm_scroller_bounce_set(ad.scroller, EINA_TRUE, EINA_TRUE);
	/* Hide horizontal & vertical scroll bar */
	elm_scroller_policy_set(ad.scroller, ELM_SCROLLER_POLICY_OFF, ELM_SCROLLER_POLICY_OFF);
	evas_object_size_hint_weight_set(ad.scroller, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	evas_object_size_hint_align_set(ad.scroller, EVAS_HINT_FILL, EVAS_HINT_FILL);
	/* Can be scrolled vertically */
	elm_object_scroll_lock_x_set(ad.scroller, EINA_TRUE);
	/* You can show effect when you reach to end of scroller */
	elm_object_style_set(ad.scroller, "effect");
	//evas_object_smart_callback_add(ad.scroller, "scroll", _scrolled_cb, NULL);
	/* pass part name as a second argument for the part which you want to fill */
	//elm_object_part_content_set(ad.layout, GRP_SCROLLER, ad.scroller);
	elm_object_part_content_set(ad.layout, "elm.swallow.content", ad.scroller);
	//elm_scroller_page_size_set(ad.scroller, ICON_WIDTH*0, ICON_HEIGHT*0);
	evas_object_show(ad.scroller);

	ad.box = elm_box_add(ad.scroller);
	evas_object_size_hint_weight_set(ad.box, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	evas_object_size_hint_fill_set(ad.box, EVAS_HINT_FILL, EVAS_HINT_FILL);
	//elm_box_horizontal_set(ad.box, EINA_TRUE);
	elm_box_homogeneous_set(ad.box, EINA_FALSE);
	elm_box_padding_set(ad.box, 0, 25);

	padding_start = evas_object_rectangle_add(ad.box);
//	int w,h;
//	evas_object_size_hint_align_set(padding_start, EVAS_HINT_FILL, 0.5);
//	evas_object_size_hint_max_get(ad.win, &w, &h);
//	evas_object_size_hint_min_get(ad.win, &w, &h);
	evas_object_size_hint_min_set(padding_start, 1, 50);
	evas_object_color_set(padding_start, 255, 0, 0, 255);
	evas_object_show(padding_start);
	//evas_object_data_set(ad.box, PADDING_START, padding_start);

	padding_end = evas_object_rectangle_add(ad.box);
//	evas_object_size_hint_max_get(padding_end, &w, &h);
	evas_object_size_hint_min_set(padding_end, 1, 50);
//	evas_object_size_hint_align_set(padding_end, EVAS_HINT_FILL, 0.5);
	evas_object_color_set(padding_end, 0, 255, 0, 255);
	evas_object_show(padding_end);
	evas_object_data_set(ad.box, PADDING_END, padding_end);

	elm_box_pack_start(ad.box, padding_start);
	elm_box_pack_end(ad.box, padding_end);

	char tmp3[128];

	ad.slider_label = elm_label_add(ad.box);
	elm_label_line_wrap_set(ad.slider_label, ELM_WRAP_MIXED); // Enable line wrapping
	evas_object_size_hint_min_set(ad.slider_label, 300, 0); // Adjust the size as needed
	snprintf(tmp3, sizeof(tmp3), "<align=center>Use calendar day</align>");
	elm_object_text_set(ad.slider_label, tmp3);
	evas_object_show(ad.slider_label);
	elm_box_pack_before(ad.box, ad.slider_label, padding_end);

	ad.slider = elm_slider_add(ad.box);
	elm_slider_min_max_set(ad.slider, 0.0, 4.0);
	evas_object_smart_callback_add(ad.slider, "changed", slider_changed_cb, NULL);
	elm_slider_value_set(ad.slider, 0.0);
	//slider_changed_cb(NULL, item, NULL);
	//evas_object_size_hint_align_set(item, EVAS_HINT_FILL, 0.5);
	evas_object_size_hint_weight_set(ad.slider, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	evas_object_size_hint_min_set(ad.slider, 200, 0); // Adjust the size as needed
	//	elm_spinner_editable_set(item, EINA_FALSE);
	//	elm_spinner_min_max_set(item, 0, 3);
	//    elm_spinner_special_value_add(item, 0, "Anchor Day");
	//    elm_spinner_special_value_add(item, 1, "Odd/Silver Day");
	//    elm_spinner_special_value_add(item, 2, "Even/Blue Day");
	//    elm_spinner_special_value_add(item, 3, "Weekend");
	//	evas_object_size_hint_align_set(item, EVAS_HINT_FILL, 0.5);
	//	evas_object_size_hint_weight_set(item, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	elm_box_pack_before(ad.box, ad.slider, padding_end);
	evas_object_show(ad.slider);
	//slider_changed_cb(NULL, ad.slider, NULL);

	ad.title_label = elm_label_add(ad.box);
	elm_label_line_wrap_set(ad.title_label, ELM_WRAP_MIXED); // Enable line wrapping
	evas_object_size_hint_min_set(ad.title_label, 300, 0); // Adjust the size as needed
	snprintf(tmp3, sizeof(tmp3), "<align=center>Title Label</align>");
	elm_object_text_set(ad.title_label, tmp3);
	evas_object_show(ad.title_label);
	elm_box_pack_before(ad.box, ad.title_label, padding_end);

	elm_object_content_set(ad.scroller, ad.box);

	evas_object_show(ad.box);

	evas_object_show(ad.layout);

	ad.schedule = populate_schedule();

	// Register the back button callback
	eext_object_event_callback_add(ad.win, EEXT_CALLBACK_BACK, back_button_cb, &ad);

//	dlog_print(DLOG_INFO, "MY_TAG", "end of app_create()");
//	populateGUI();

	/* Show window after main view is set up */
	evas_object_show(ad.win);

	return true;
}

/*
 * @brief: This callback function is called when another application
 * sends the launch request to the application
 */
static void app_control(app_control_h app_control, void *user_data)
{
	/* Handle the launch request. */
}

/*
 * @brief: This callback function is called each time
 * the application is completely obscured by another application
 * and becomes invisible to the user
 */
static void app_pause(void *user_data)
{
	/* Take necessary actions when application becomes invisible. */

	// Stop the timer when the app goes into the background
	ecore_timer_freeze(ad.timer_RefreshGUI);

//	if (timer)
//	{
//		ecore_timer_del(timer);
//		timer = NULL;
//	}
}

static int convertSundayBasedWdayToMondayBasedWday(int sundayBasedWday)
{
	int mondayBasedWday = (sundayBasedWday+6)%7;
	return(mondayBasedWday);
}

static int convertMondayBasedWdayToSundayBasedWday(int mondayBasedWday)
{
	int sundayBasedWday = (mondayBasedWday+1)%7;
	return(sundayBasedWday);
}

/*
 * @brief: This callback function is called each time
 * the application becomes visible to the user
 */
static void app_resume(void *user_data)
{
	/* Take necessary actions when application becomes visible. */

//	dlog_print(DLOG_INFO, "MY_TAG", "Beginning of app_resume()");

	// Initialize override software clock
	if(CLOCK_OVERRIDE_ENABLED && debug_clock_timer == NULL)
	{
		struct tm *timeinfo;
		timeinfo = getCurrentTime();

		memcpy(&debug_clock, timeinfo, sizeof(struct tm));

		int override_tm_wday = convertMondayBasedWdayToSundayBasedWday(CLOCK_OVERRIDE_DAY);

		debug_clock.tm_mday = debug_clock.tm_mday + (override_tm_wday-timeinfo->tm_wday);
		debug_clock.tm_hour = CLOCK_OVERRIDE_HOUR;
		debug_clock.tm_min = CLOCK_OVERRIDE_MIN;
		debug_clock.tm_sec = CLOCK_OVERRIDE_SEC;
		mktime(&debug_clock); //normalize time structure

//			dlog_print(DLOG_INFO, "MY_TAG", "Debug_Clock is initiated to: WDay %d, Hour %d, Min %d, Sec %d", debug_clock.tm_wday, debug_clock.tm_hour, debug_clock.tm_min, debug_clock.tm_sec);

		//Start override software clock timer which increases clock by 1 sec each second
		debug_clock_timer = ecore_timer_add(1.0, debug_clock_timer_cb, NULL);
	}

	/* Initialize or wake timer_RefreshGUI */
	if(ad.timer_RefreshGUI == NULL){
		ad.timer_RefreshGUI = ecore_timer_add(TIMER_INTERVAL, timer_RefreshGUI_cb, NULL);
	}else{
		ecore_timer_thaw(ad.timer_RefreshGUI);
	}

	timer_RefreshGUI_cb(NULL); //In case TIMER_INTERVAL is too long, call timer_cb first to update info immediately

//	dlog_print(DLOG_INFO, "MY_TAG", "End of app_resume()");
}

/*
 * @brief: This callback function is called once after the main loop of the application exits
 */
static void app_terminate(void *user_data)
{
	/* Release all resources. */
	if (ad.win == NULL) {
		return;
	}

	evas_object_del(ad.win);

	// Your app termination code here
	if (ad.timer_RefreshGUI) {
		ecore_timer_del(ad.timer_RefreshGUI);
		ad.timer_RefreshGUI = NULL;
	}
}

/*
 * @brief: This function will be called when the language is changed
 */
static void ui_app_lang_changed(app_event_info_h event_info, void *user_data)
{
	/*APP_EVENT_LANGUAGE_CHANGED*/
	char *locale = NULL;

	system_settings_get_value_string(SYSTEM_SETTINGS_KEY_LOCALE_LANGUAGE, &locale);

	if (locale != NULL) {
		elm_language_set(locale);
		free(locale);
	}
	return;
}

/*
 * @brief: The function will be called when the window is deleted
 * @param[user_data] : The data passed to the function
 * @param[obj] : The object, normally window
 * @param[event_info] : Information regarding with the event
 */
static void _win_delete_request_cb(void *user_data, Evas_Object *obj, void *event_info)
{
	ui_app_exit();
}

/*
 * @brief: Main function of the application
 */
int main(int argc, char *argv[])
{
	int ret;

	ui_app_lifecycle_callback_s event_callback = {0, };
	app_event_handler_h handlers[5] = {NULL, };

	event_callback.create = app_create;
	event_callback.terminate = app_terminate;
	event_callback.pause = app_pause;
	event_callback.resume = app_resume;
	event_callback.app_control = app_control;

	/*
	 * If you want to handling more events,
	 * Please check the application lifecycle guide
	 */
	ui_app_add_event_handler(&handlers[APP_EVENT_LANGUAGE_CHANGED], APP_EVENT_LANGUAGE_CHANGED, ui_app_lang_changed, NULL);

	ret = ui_app_main(argc, argv, &event_callback, NULL);
	if (ret != APP_ERROR_NONE) {
		dlog_print(DLOG_ERROR, LOG_TAG, "ui_app_main() is failed. err = %d", ret);
	}

	return ret;
}
